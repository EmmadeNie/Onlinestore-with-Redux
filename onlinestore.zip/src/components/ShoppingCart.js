import React from "react";
import { useSelector, useDispatch } from "react-redux";

function ShoppingCart() {
  const shoppingCart = useSelector((state) => state.shoppingCart);

  const arrayOfAmounts = shoppingCart.products.map((item) => item.amount);
  const totalAmount = arrayOfAmounts.reduce(function (a, b) {
    return a + b;
  }, 0);

  const arrayOfPrices = shoppingCart.products.map(
    (item) => item.price * item.amount
  );
  const totalPrice = arrayOfPrices.reduce(function (a, b) {
    return a + b;
  }, 0);

  console.log("lala", totalPrice);

  return (
    <div>
      <h1>Shopping Cart</h1>
      <p>total amount: {totalAmount}</p>
      <p>total price: {totalPrice} </p>
    </div>
  );
}

export default ShoppingCart;
