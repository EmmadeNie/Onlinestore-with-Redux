import React, { useEffect } from "react";
import { connect } from "react-redux";
import { fetchProducts } from "../redux";
import { ProductComponent } from "./ProductComponent";

function ProductList({ productsData, fetchProducts }) {
  useEffect(() => {
    fetchProducts();
  }, []);
  return productsData.loading ? (
    <h2>loading</h2>
  ) : productsData.error ? (
    <h2>{productsData.error}</h2>
  ) : (
    <div>
      <h2>product list</h2>
      <div>
        {productsData &&
          productsData.products &&
          productsData.products.map((product) => (
            <ProductComponent product={product} />
          ))}
      </div>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    productsData: state.products,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchProducts: () => dispatch(fetchProducts()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ProductList);
